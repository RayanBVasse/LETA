# Individual Author Profiles
## Persona-Level Insights via GNA Methodology

**Generated**: November 27, 2024  
**Dataset**: 18,604 posts from 40 authors (2000-2004)  
**Methods**: Integrated emotion, trajectory, topic, and linguistic analysis

---

## Author 49663

### 381 posts over 1420 days. Optimistic, moderately stable (Joy-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 381
- Timespan: 1420 days (3.9 years)
- Mean post length: 756 characters
- Lexical diversity: 0.214

**😊 Emotional Profile:**

- Baseline sentiment: +0.226
- Dominant emotion: Joy (0.4%)
- Emotional variance: 0.0124
- Mean intensity: 0.017

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000042 per day
- Sentiment range: 1.992
- Inflection points: 9
- Change: +0.263 → +0.325 (Δ +0.062)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (31.6%)
- Diversity: 2.026 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 46.3/1000 words
- Cognitive: 4.0/1000 words
- Exclamations: 8.7/1000 words

**🎯 Distinctive Characteristics:**

Very positive; Repetitive

---

## Author 105748

### 334 posts over 0 days. Slightly positive, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 334
- Timespan: 0 days (0.0 years)
- Mean post length: 524 characters
- Lexical diversity: 0.246

**😊 Emotional Profile:**

- Baseline sentiment: +0.093
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0110
- Mean intensity: 0.013

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000000 per day
- Sentiment range: 1.985
- Inflection points: 8
- Change: +0.027 → -0.183 (Δ -0.210)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (23.7%)
- Diversity: 2.123 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 48.4/1000 words
- Cognitive: 4.5/1000 words
- Exclamations: 14.7/1000 words

**🎯 Distinctive Characteristics:**

Repetitive; Infrequent poster

---

## Author 106651

### 379 posts over 0 days. Pessimistic, stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 379
- Timespan: 0 days (0.0 years)
- Mean post length: 476 characters
- Lexical diversity: 0.220

**😊 Emotional Profile:**

- Baseline sentiment: -0.066
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0100
- Mean intensity: 0.012

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000000 per day
- Sentiment range: 1.986
- Inflection points: 5
- Change: -0.117 → -0.389 (Δ -0.272)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (26.6%)
- Diversity: 2.131 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 48.1/1000 words
- Cognitive: 6.1/1000 words
- Exclamations: 4.3/1000 words

**🎯 Distinctive Characteristics:**

Very negative; Repetitive

---

## Author 216413

### 311 posts over 1179 days. Slightly positive, stable (Joy-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 311
- Timespan: 1179 days (3.2 years)
- Mean post length: 1273 characters
- Lexical diversity: 0.164

**😊 Emotional Profile:**

- Baseline sentiment: +0.052
- Dominant emotion: Joy (0.4%)
- Emotional variance: 0.0096
- Mean intensity: 0.016

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000051 per day
- Sentiment range: 1.985
- Inflection points: 11
- Change: +0.119 → +0.240 (Δ +0.121)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (30.4%)
- Diversity: 2.000 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 53.9/1000 words
- Cognitive: 3.2/1000 words
- Exclamations: 1.6/1000 words

**🎯 Distinctive Characteristics:**

Topic-focused; Repetitive; Infrequent poster

---

## Author 271835

### 311 posts over 78 days. Neutral, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 311
- Timespan: 78 days (0.2 years)
- Mean post length: 274 characters
- Lexical diversity: 0.304

**😊 Emotional Profile:**

- Baseline sentiment: +0.002
- Dominant emotion: Neutral (0.8%)
- Emotional variance: 0.0156
- Mean intensity: 0.011

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000458 per day
- Sentiment range: 1.994
- Inflection points: 5
- Change: +0.000 → -0.191 (Δ -0.191)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (23.4%)
- Diversity: 2.041 entropy
- Cluster: Group 2

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 15.4/1000 words
- Cognitive: 2.2/1000 words
- Exclamations: 11.4/1000 words

**🎯 Distinctive Characteristics:**

Repetitive; Infrequent poster

---

## Author 303162

### 580 posts over 0 days. Slightly positive, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 580
- Timespan: 0 days (0.0 years)
- Mean post length: 513 characters
- Lexical diversity: 0.186

**😊 Emotional Profile:**

- Baseline sentiment: +0.111
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0129
- Mean intensity: 0.014

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000000 per day
- Sentiment range: 1.995
- Inflection points: 6
- Change: +0.198 → +0.898 (Δ +0.700)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (33.0%)
- Diversity: 1.983 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 56.7/1000 words
- Cognitive: 5.8/1000 words
- Exclamations: 6.9/1000 words

**🎯 Distinctive Characteristics:**

Topic-focused; Repetitive

---

## Author 322624

### 334 posts over 0 days. Slightly positive, volatile (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 334
- Timespan: 0 days (0.0 years)
- Mean post length: 308 characters
- Lexical diversity: 0.276

**😊 Emotional Profile:**

- Baseline sentiment: +0.140
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0322
- Mean intensity: 0.026

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000000 per day
- Sentiment range: 1.994
- Inflection points: 11
- Change: +0.376 → +0.010 (Δ -0.367)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (38.7%)
- Diversity: 1.932 entropy
- Cluster: Group 0

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 49.2/1000 words
- Cognitive: 4.4/1000 words
- Exclamations: 60.1/1000 words

**🎯 Distinctive Characteristics:**

Highly volatile; Topic-focused; Repetitive; Very expressive; Infrequent poster

---

## Author 449628

### 1249 posts over 940 days. Slightly positive, stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Improving over time.

**📊 Core Statistics:**

- Posts: 1249
- Timespan: 940 days (2.6 years)
- Mean post length: 407 characters
- Lexical diversity: 0.182

**😊 Emotional Profile:**

- Baseline sentiment: +0.064
- Dominant emotion: Neutral (0.8%)
- Emotional variance: 0.0079
- Mean intensity: 0.008

**📈 Temporal Trajectory:**

- Trend: **Improving** ↗
- Slope: +0.000149 per day
- Sentiment range: 1.990
- Inflection points: 4
- Change: -0.005 → +0.191 (Δ +0.197)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (22.1%)
- Diversity: 2.153 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 31.1/1000 words
- Cognitive: 3.2/1000 words
- Exclamations: 6.0/1000 words

**🎯 Distinctive Characteristics:**

Extremely stable; Topic-diverse; Repetitive; Improving trajectory; Highly prolific

---

## Author 576311

### 352 posts over 839 days. Pessimistic, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 352
- Timespan: 839 days (2.3 years)
- Mean post length: 594 characters
- Lexical diversity: 0.220

**😊 Emotional Profile:**

- Baseline sentiment: -0.057
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0121
- Mean intensity: 0.013

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.000179 per day
- Sentiment range: 1.991
- Inflection points: 11
- Change: -0.076 → -0.005 (Δ +0.071)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (31.2%)
- Diversity: 2.056 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 46.5/1000 words
- Cognitive: 4.6/1000 words
- Exclamations: 5.4/1000 words

**🎯 Distinctive Characteristics:**

Very negative; Repetitive

---

## Author 589736

### 589 posts over 0 days. Neutral, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 589
- Timespan: 0 days (0.0 years)
- Mean post length: 426 characters
- Lexical diversity: 0.224

**😊 Emotional Profile:**

- Baseline sentiment: -0.026
- Dominant emotion: Neutral (0.7%)
- Emotional variance: 0.0165
- Mean intensity: 0.016

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000000 per day
- Sentiment range: 1.995
- Inflection points: 8
- Change: -0.181 → +0.344 (Δ +0.525)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (19.9%)
- Diversity: 2.174 entropy
- Cluster: Group 4

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 28.8/1000 words
- Cognitive: 4.4/1000 words
- Exclamations: 7.3/1000 words

**🎯 Distinctive Characteristics:**

Topic-diverse; Repetitive

---

## Author 595404

### 455 posts over 852 days. Neutral, stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Other-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 455
- Timespan: 852 days (2.3 years)
- Mean post length: 903 characters
- Lexical diversity: 0.228

**😊 Emotional Profile:**

- Baseline sentiment: -0.014
- Dominant emotion: Neutral (0.5%)
- Emotional variance: 0.0039
- Mean intensity: 0.006

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.000048 per day
- Sentiment range: 1.964
- Inflection points: 11
- Change: -0.194 → -0.249 (Δ -0.055)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (35.1%)
- Diversity: 2.016 entropy
- Cluster: Group 0

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Other-focused**
- First-person: 34.1/1000 words
- Cognitive: 2.5/1000 words
- Exclamations: 0.2/1000 words

**🎯 Distinctive Characteristics:**

Extremely stable; Repetitive

---

## Author 605396

### 413 posts over 844 days. Neutral, stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Improving over time.

**📊 Core Statistics:**

- Posts: 413
- Timespan: 844 days (2.3 years)
- Mean post length: 698 characters
- Lexical diversity: 0.223

**😊 Emotional Profile:**

- Baseline sentiment: +0.006
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0076
- Mean intensity: 0.010

**📈 Temporal Trajectory:**

- Trend: **Improving** ↗
- Slope: +0.000313 per day
- Sentiment range: 1.988
- Inflection points: 9
- Change: -0.196 → +0.089 (Δ +0.284)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (34.6%)
- Diversity: 2.015 entropy
- Cluster: Group 0

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 32.4/1000 words
- Cognitive: 1.6/1000 words
- Exclamations: 1.2/1000 words

**🎯 Distinctive Characteristics:**

Extremely stable; Repetitive; Improving trajectory

---

## Author 734562

### 586 posts over 0 days. Neutral, volatile (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 586
- Timespan: 0 days (0.0 years)
- Mean post length: 443 characters
- Lexical diversity: 0.225

**😊 Emotional Profile:**

- Baseline sentiment: -0.002
- Dominant emotion: Neutral (0.7%)
- Emotional variance: 0.0208
- Mean intensity: 0.020

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000000 per day
- Sentiment range: 1.995
- Inflection points: 6
- Change: +0.199 → -0.061 (Δ -0.260)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (17.4%)
- Diversity: 2.203 entropy
- Cluster: Group 4

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 28.9/1000 words
- Cognitive: 4.6/1000 words
- Exclamations: 7.1/1000 words

**🎯 Distinctive Characteristics:**

Topic-diverse; Repetitive

---

## Author 780903

### 384 posts over 733 days. Neutral, stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 384
- Timespan: 733 days (2.0 years)
- Mean post length: 1780 characters
- Lexical diversity: 0.143

**😊 Emotional Profile:**

- Baseline sentiment: +0.036
- Dominant emotion: Neutral (0.4%)
- Emotional variance: 0.0052
- Mean intensity: 0.008

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000013 per day
- Sentiment range: 1.973
- Inflection points: 8
- Change: -0.029 → +0.184 (Δ +0.213)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (22.8%)
- Diversity: 2.147 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 32.3/1000 words
- Cognitive: 5.3/1000 words
- Exclamations: 1.8/1000 words

**🎯 Distinctive Characteristics:**

Extremely stable; Repetitive

---

## Author 798653

### 290 posts over 759 days. Neutral, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 290
- Timespan: 759 days (2.1 years)
- Mean post length: 449 characters
- Lexical diversity: 0.255

**😊 Emotional Profile:**

- Baseline sentiment: +0.031
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0120
- Mean intensity: 0.014

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000135 per day
- Sentiment range: 1.991
- Inflection points: 7
- Change: +0.000 → +0.358 (Δ +0.358)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (22.6%)
- Diversity: 2.171 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 41.4/1000 words
- Cognitive: 6.1/1000 words
- Exclamations: 4.9/1000 words

**🎯 Distinctive Characteristics:**

Topic-diverse; Repetitive; Infrequent poster

---

## Author 883178

### 470 posts over 719 days. Neutral, volatile (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 470
- Timespan: 719 days (2.0 years)
- Mean post length: 751 characters
- Lexical diversity: 0.201

**😊 Emotional Profile:**

- Baseline sentiment: +0.028
- Dominant emotion: Neutral (0.4%)
- Emotional variance: 0.0209
- Mean intensity: 0.017

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000109 per day
- Sentiment range: 1.997
- Inflection points: 14
- Change: +0.006 → +0.023 (Δ +0.016)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (28.4%)
- Diversity: 2.090 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 47.5/1000 words
- Cognitive: 5.0/1000 words
- Exclamations: 4.0/1000 words

**🎯 Distinctive Characteristics:**

Repetitive; Emotionally turbulent

---

## Author 907450

### 376 posts over 0 days. Optimistic, moderately stable (Joy-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 376
- Timespan: 0 days (0.0 years)
- Mean post length: 755 characters
- Lexical diversity: 0.182

**😊 Emotional Profile:**

- Baseline sentiment: +0.173
- Dominant emotion: Joy (0.5%)
- Emotional variance: 0.0162
- Mean intensity: 0.022

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000000 per day
- Sentiment range: 1.987
- Inflection points: 8
- Change: -0.065 → +0.030 (Δ +0.095)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (22.2%)
- Diversity: 2.138 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 48.4/1000 words
- Cognitive: 7.0/1000 words
- Exclamations: 13.2/1000 words

**🎯 Distinctive Characteristics:**

Repetitive

---

## Author 942828

### 587 posts over 664 days. Slightly positive, stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Other-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 587
- Timespan: 664 days (1.8 years)
- Mean post length: 853 characters
- Lexical diversity: 0.165

**😊 Emotional Profile:**

- Baseline sentiment: +0.144
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0077
- Mean intensity: 0.010

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000065 per day
- Sentiment range: 1.981
- Inflection points: 9
- Change: +0.532 → +0.007 (Δ -0.525)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (31.6%)
- Diversity: 2.023 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Other-focused**
- First-person: 18.4/1000 words
- Cognitive: 2.7/1000 words
- Exclamations: 3.3/1000 words

**🎯 Distinctive Characteristics:**

Extremely stable; Repetitive

---

## Author 944569

### 361 posts over 629 days. Slightly positive, volatile (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 361
- Timespan: 629 days (1.7 years)
- Mean post length: 384 characters
- Lexical diversity: 0.271

**😊 Emotional Profile:**

- Baseline sentiment: +0.065
- Dominant emotion: Neutral (0.5%)
- Emotional variance: 0.0260
- Mean intensity: 0.025

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000287 per day
- Sentiment range: 1.997
- Inflection points: 11
- Change: +0.197 → -0.192 (Δ -0.389)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (19.8%)
- Diversity: 2.131 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 49.1/1000 words
- Cognitive: 6.6/1000 words
- Exclamations: 44.4/1000 words

**🎯 Distinctive Characteristics:**

Highly volatile; Repetitive; Very expressive

---

## Author 955372

### 429 posts over 656 days. Slightly positive, volatile (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Declining over time.

**📊 Core Statistics:**

- Posts: 429
- Timespan: 656 days (1.8 years)
- Mean post length: 352 characters
- Lexical diversity: 0.226

**😊 Emotional Profile:**

- Baseline sentiment: +0.074
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0248
- Mean intensity: 0.029

**📈 Temporal Trajectory:**

- Trend: **Declining** ↘
- Slope: -0.000317 per day
- Sentiment range: 1.997
- Inflection points: 6
- Change: -0.037 → -0.160 (Δ -0.122)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (28.0%)
- Diversity: 2.062 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 47.0/1000 words
- Cognitive: 4.7/1000 words
- Exclamations: 22.3/1000 words

**🎯 Distinctive Characteristics:**

Repetitive; Very expressive; Declining trajectory

---

## Author 958176

### 624 posts over 563 days. Neutral, volatile (Neutral-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 624
- Timespan: 563 days (1.5 years)
- Mean post length: 654 characters
- Lexical diversity: 0.165

**😊 Emotional Profile:**

- Baseline sentiment: +0.043
- Dominant emotion: Neutral (0.5%)
- Emotional variance: 0.0256
- Mean intensity: 0.022

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000005 per day
- Sentiment range: 1.998
- Inflection points: 11
- Change: -0.195 → -0.367 (Δ -0.172)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (31.1%)
- Diversity: 2.000 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 51.6/1000 words
- Cognitive: 6.2/1000 words
- Exclamations: 13.0/1000 words

**🎯 Distinctive Characteristics:**

Highly volatile; Topic-focused; Repetitive

---

## Author 988941

### 418 posts over 578 days. Optimistic, volatile (Neutral-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Declining over time.

**📊 Core Statistics:**

- Posts: 418
- Timespan: 578 days (1.6 years)
- Mean post length: 446 characters
- Lexical diversity: 0.191

**😊 Emotional Profile:**

- Baseline sentiment: +0.165
- Dominant emotion: Neutral (0.5%)
- Emotional variance: 0.0252
- Mean intensity: 0.023

**📈 Temporal Trajectory:**

- Trend: **Declining** ↘
- Slope: -0.000380 per day
- Sentiment range: 1.996
- Inflection points: 10
- Change: +0.130 → +0.195 (Δ +0.065)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (39.1%)
- Diversity: 1.972 entropy
- Cluster: Group 0

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 52.4/1000 words
- Cognitive: 4.8/1000 words
- Exclamations: 26.2/1000 words

**🎯 Distinctive Characteristics:**

Highly volatile; Topic-focused; Repetitive; Very expressive; Declining trajectory

---

## Author 1078410

### 550 posts over 475 days. Optimistic, moderately stable (Neutral-dominant). Writes about entertainment. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 550
- Timespan: 475 days (1.3 years)
- Mean post length: 406 characters
- Lexical diversity: 0.203

**😊 Emotional Profile:**

- Baseline sentiment: +0.150
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0120
- Mean intensity: 0.014

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.000144 per day
- Sentiment range: 1.988
- Inflection points: 6
- Change: +0.385 → +0.779 (Δ +0.393)

**📝 Topic Distribution:**

- Dominant: **Entertainment** (21.6%)
- Diversity: 2.136 entropy
- Cluster: Group 2

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 27.7/1000 words
- Cognitive: 3.4/1000 words
- Exclamations: 11.0/1000 words

**🎯 Distinctive Characteristics:**

Entertainment-specialist; Repetitive

---

## Author 1093457

### 441 posts over 572 days. Optimistic, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 441
- Timespan: 572 days (1.6 years)
- Mean post length: 461 characters
- Lexical diversity: 0.181

**😊 Emotional Profile:**

- Baseline sentiment: +0.171
- Dominant emotion: Neutral (0.5%)
- Emotional variance: 0.0170
- Mean intensity: 0.022

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.000233 per day
- Sentiment range: 1.993
- Inflection points: 10
- Change: +0.128 → +0.575 (Δ +0.447)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (41.5%)
- Diversity: 1.934 entropy
- Cluster: Group 0

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 55.2/1000 words
- Cognitive: 5.3/1000 words
- Exclamations: 31.2/1000 words

**🎯 Distinctive Characteristics:**

Topic-focused; Repetitive; Very expressive

---

## Author 1093691

### 414 posts over 581 days. Slightly positive, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 414
- Timespan: 581 days (1.6 years)
- Mean post length: 468 characters
- Lexical diversity: 0.186

**😊 Emotional Profile:**

- Baseline sentiment: +0.139
- Dominant emotion: Neutral (0.4%)
- Emotional variance: 0.0150
- Mean intensity: 0.018

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.000323 per day
- Sentiment range: 1.993
- Inflection points: 11
- Change: -0.164 → +0.006 (Δ +0.170)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (41.8%)
- Diversity: 1.922 entropy
- Cluster: Group 0

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 55.6/1000 words
- Cognitive: 5.5/1000 words
- Exclamations: 34.8/1000 words

**🎯 Distinctive Characteristics:**

Topic-focused; Repetitive; Very expressive

---

## Author 1107146

### 576 posts over 538 days. Slightly positive, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Declining over time.

**📊 Core Statistics:**

- Posts: 576
- Timespan: 538 days (1.5 years)
- Mean post length: 605 characters
- Lexical diversity: 0.170

**😊 Emotional Profile:**

- Baseline sentiment: +0.057
- Dominant emotion: Neutral (0.5%)
- Emotional variance: 0.0184
- Mean intensity: 0.022

**📈 Temporal Trajectory:**

- Trend: **Declining** ↘
- Slope: -0.000305 per day
- Sentiment range: 1.995
- Inflection points: 7
- Change: +0.069 → -0.001 (Δ -0.071)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (30.9%)
- Diversity: 2.025 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 52.0/1000 words
- Cognitive: 6.9/1000 words
- Exclamations: 14.1/1000 words

**🎯 Distinctive Characteristics:**

Repetitive; Declining trajectory

---

## Author 1270648

### 501 posts over 1213 days. Neutral, volatile (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Improving over time.

**📊 Core Statistics:**

- Posts: 501
- Timespan: 1213 days (3.3 years)
- Mean post length: 391 characters
- Lexical diversity: 0.246

**😊 Emotional Profile:**

- Baseline sentiment: +0.040
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0202
- Mean intensity: 0.015

**📈 Temporal Trajectory:**

- Trend: **Improving** ↗
- Slope: +0.000166 per day
- Sentiment range: 1.996
- Inflection points: 7
- Change: -0.194 → -0.158 (Δ +0.037)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (26.2%)
- Diversity: 2.131 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 42.4/1000 words
- Cognitive: 6.0/1000 words
- Exclamations: 29.5/1000 words

**🎯 Distinctive Characteristics:**

Repetitive; Very expressive; Improving trajectory

---

## Author 1281160

### 338 posts over 503 days. Slightly positive, stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 338
- Timespan: 503 days (1.4 years)
- Mean post length: 882 characters
- Lexical diversity: 0.213

**😊 Emotional Profile:**

- Baseline sentiment: +0.103
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0046
- Mean intensity: 0.006

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000099 per day
- Sentiment range: 1.975
- Inflection points: 6
- Change: +0.000 → +0.334 (Δ +0.334)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (30.9%)
- Diversity: 2.086 entropy
- Cluster: Group 0

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 36.4/1000 words
- Cognitive: 3.7/1000 words
- Exclamations: 6.4/1000 words

**🎯 Distinctive Characteristics:**

Extremely stable; Repetitive; Infrequent poster

---

## Author 1325355

### 467 posts over 570 days. Slightly positive, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 467
- Timespan: 570 days (1.6 years)
- Mean post length: 532 characters
- Lexical diversity: 0.224

**😊 Emotional Profile:**

- Baseline sentiment: +0.085
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0128
- Mean intensity: 0.011

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000191 per day
- Sentiment range: 1.984
- Inflection points: 7
- Change: -0.193 → +0.192 (Δ +0.384)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (28.2%)
- Diversity: 2.119 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 39.5/1000 words
- Cognitive: 3.6/1000 words
- Exclamations: 8.9/1000 words

**🎯 Distinctive Characteristics:**

Repetitive

---

## Author 1417798

### 323 posts over 475 days. Optimistic, stable (Joy-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 323
- Timespan: 475 days (1.3 years)
- Mean post length: 1481 characters
- Lexical diversity: 0.152

**😊 Emotional Profile:**

- Baseline sentiment: +0.337
- Dominant emotion: Joy (0.7%)
- Emotional variance: 0.0063
- Mean intensity: 0.016

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000159 per day
- Sentiment range: 1.979
- Inflection points: 12
- Change: +0.377 → +0.523 (Δ +0.146)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (37.3%)
- Diversity: 1.965 entropy
- Cluster: Group 0

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 50.5/1000 words
- Cognitive: 7.2/1000 words
- Exclamations: 19.2/1000 words

**🎯 Distinctive Characteristics:**

Very positive; Extremely stable; Topic-focused; Repetitive; Very expressive; Emotionally turbulent; Infrequent poster

---

## Author 1470319

### 325 posts over 453 days. Neutral, stable (Joy-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 325
- Timespan: 453 days (1.2 years)
- Mean post length: 713 characters
- Lexical diversity: 0.176

**😊 Emotional Profile:**

- Baseline sentiment: +0.049
- Dominant emotion: Joy (0.4%)
- Emotional variance: 0.0099
- Mean intensity: 0.014

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000270 per day
- Sentiment range: 1.988
- Inflection points: 10
- Change: -0.006 → +0.729 (Δ +0.735)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (31.7%)
- Diversity: 1.989 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 50.8/1000 words
- Cognitive: 7.5/1000 words
- Exclamations: 10.3/1000 words

**🎯 Distinctive Characteristics:**

Topic-focused; Repetitive; Infrequent poster

---

## Author 1472995

### 318 posts over 452 days. Slightly positive, stable (Joy-dominant). Writes about daily activities. Mixed-Casual-Other-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 318
- Timespan: 452 days (1.2 years)
- Mean post length: 735 characters
- Lexical diversity: 0.176

**😊 Emotional Profile:**

- Baseline sentiment: +0.058
- Dominant emotion: Joy (0.4%)
- Emotional variance: 0.0085
- Mean intensity: 0.015

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000095 per day
- Sentiment range: 1.989
- Inflection points: 11
- Change: +0.317 → +0.009 (Δ -0.308)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (30.6%)
- Diversity: 2.008 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Other-focused**
- First-person: 48.9/1000 words
- Cognitive: 7.6/1000 words
- Exclamations: 9.6/1000 words

**🎯 Distinctive Characteristics:**

Repetitive; Infrequent poster

---

## Author 1473902

### 343 posts over 0 days. Slightly positive, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 343
- Timespan: 0 days (0.0 years)
- Mean post length: 417 characters
- Lexical diversity: 0.270

**😊 Emotional Profile:**

- Baseline sentiment: +0.115
- Dominant emotion: Neutral (0.6%)
- Emotional variance: 0.0109
- Mean intensity: 0.014

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000000 per day
- Sentiment range: 1.992
- Inflection points: 13
- Change: +0.196 → +0.029 (Δ -0.167)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (28.6%)
- Diversity: 2.088 entropy
- Cluster: Group 3

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 48.3/1000 words
- Cognitive: 5.0/1000 words
- Exclamations: 13.6/1000 words

**🎯 Distinctive Characteristics:**

Repetitive; Emotionally turbulent; Infrequent poster

---

## Author 1784456

### 519 posts over 1055 days. Neutral, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 519
- Timespan: 1055 days (2.9 years)
- Mean post length: 525 characters
- Lexical diversity: 0.193

**😊 Emotional Profile:**

- Baseline sentiment: +0.015
- Dominant emotion: Neutral (0.4%)
- Emotional variance: 0.0116
- Mean intensity: 0.019

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.000072 per day
- Sentiment range: 1.992
- Inflection points: 11
- Change: +0.383 → -0.009 (Δ -0.391)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (28.2%)
- Diversity: 2.085 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 48.0/1000 words
- Cognitive: 6.2/1000 words
- Exclamations: 65.4/1000 words

**🎯 Distinctive Characteristics:**

Repetitive; Very expressive

---

## Author 1862467

### 324 posts over 333 days. Neutral, stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 324
- Timespan: 333 days (0.9 years)
- Mean post length: 1235 characters
- Lexical diversity: 0.201

**😊 Emotional Profile:**

- Baseline sentiment: +0.030
- Dominant emotion: Neutral (0.4%)
- Emotional variance: 0.0057
- Mean intensity: 0.009

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.000346 per day
- Sentiment range: 1.983
- Inflection points: 9
- Change: -0.147 → -0.106 (Δ +0.040)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (23.2%)
- Diversity: 2.194 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 30.3/1000 words
- Cognitive: 3.5/1000 words
- Exclamations: 3.7/1000 words

**🎯 Distinctive Characteristics:**

Extremely stable; Topic-diverse; Repetitive; Infrequent poster

---

## Author 1975546

### 598 posts over 0 days. Neutral, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 598
- Timespan: 0 days (0.0 years)
- Mean post length: 406 characters
- Lexical diversity: 0.239

**😊 Emotional Profile:**

- Baseline sentiment: -0.023
- Dominant emotion: Neutral (0.7%)
- Emotional variance: 0.0173
- Mean intensity: 0.017

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: +0.000000 per day
- Sentiment range: 1.993
- Inflection points: 6
- Change: +0.198 → -0.181 (Δ -0.379)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (19.8%)
- Diversity: 2.165 entropy
- Cluster: Group 4

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 27.0/1000 words
- Cognitive: 4.1/1000 words
- Exclamations: 8.6/1000 words

**🎯 Distinctive Characteristics:**

Topic-diverse; Repetitive

---

## Author 2200026

### 282 posts over 66 days. Neutral, moderately stable (Neutral-dominant). Writes about technology. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 282
- Timespan: 66 days (0.2 years)
- Mean post length: 252 characters
- Lexical diversity: 0.313

**😊 Emotional Profile:**

- Baseline sentiment: -0.005
- Dominant emotion: Neutral (0.8%)
- Emotional variance: 0.0197
- Mean intensity: 0.012

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.000208 per day
- Sentiment range: 1.996
- Inflection points: 6
- Change: +0.000 → +0.000 (Δ +0.000)

**📝 Topic Distribution:**

- Dominant: **Technology** (21.6%)
- Diversity: 2.091 entropy
- Cluster: Group 2

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 13.6/1000 words
- Cognitive: 2.5/1000 words
- Exclamations: 14.2/1000 words

**🎯 Distinctive Characteristics:**

Technology-specialist; Repetitive; Infrequent poster

---

## Author 2866266

### 314 posts over 182 days. Neutral, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 314
- Timespan: 182 days (0.5 years)
- Mean post length: 269 characters
- Lexical diversity: 0.216

**😊 Emotional Profile:**

- Baseline sentiment: -0.012
- Dominant emotion: Neutral (0.7%)
- Emotional variance: 0.0104
- Mean intensity: 0.011

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.000493 per day
- Sentiment range: 1.987
- Inflection points: 8
- Change: +0.000 → -0.552 (Δ -0.552)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (21.7%)
- Diversity: 2.158 entropy
- Cluster: Group 1

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 55.1/1000 words
- Cognitive: 5.2/1000 words
- Exclamations: 43.5/1000 words

**🎯 Distinctive Characteristics:**

Topic-diverse; Repetitive; Very expressive; Infrequent poster

---

## Author 3517276

### 292 posts over 70 days. Neutral, stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Self-focused style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 292
- Timespan: 70 days (0.2 years)
- Mean post length: 181 characters
- Lexical diversity: 0.306

**😊 Emotional Profile:**

- Baseline sentiment: -0.044
- Dominant emotion: Neutral (0.8%)
- Emotional variance: 0.0085
- Mean intensity: 0.008

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.001474 per day
- Sentiment range: 1.984
- Inflection points: 8
- Change: +0.009 → +0.000 (Δ -0.009)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (32.8%)
- Diversity: 2.009 entropy
- Cluster: Group 0

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Self-focused**
- First-person: 51.2/1000 words
- Cognitive: 4.1/1000 words
- Exclamations: 2.8/1000 words

**🎯 Distinctive Characteristics:**

Repetitive; Infrequent poster

---

## Author 3522724

### 277 posts over 71 days. Neutral, moderately stable (Neutral-dominant). Writes about daily activities. Mixed-Casual-Balanced style. Stable trajectory.

**📊 Core Statistics:**

- Posts: 277
- Timespan: 71 days (0.2 years)
- Mean post length: 195 characters
- Lexical diversity: 0.309

**😊 Emotional Profile:**

- Baseline sentiment: -0.011
- Dominant emotion: Neutral (0.8%)
- Emotional variance: 0.0102
- Mean intensity: 0.009

**📈 Temporal Trajectory:**

- Trend: **Stable** →
- Slope: -0.000896 per day
- Sentiment range: 1.981
- Inflection points: 3
- Change: +0.000 → +0.000 (Δ +0.000)

**📝 Topic Distribution:**

- Dominant: **Daily Activities** (34.2%)
- Diversity: 1.978 entropy
- Cluster: Group 0

**✍️ Writing Style:**

- Classification: **Mixed-Casual-Balanced**
- First-person: 45.5/1000 words
- Cognitive: 5.6/1000 words
- Exclamations: 3.6/1000 words

**🎯 Distinctive Characteristics:**

Topic-focused; Repetitive; Infrequent poster

---

